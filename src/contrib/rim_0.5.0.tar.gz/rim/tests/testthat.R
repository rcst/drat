library(testthat)
test_check("rim")